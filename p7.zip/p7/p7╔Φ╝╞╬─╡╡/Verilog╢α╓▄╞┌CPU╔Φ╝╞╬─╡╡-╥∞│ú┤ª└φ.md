# Verilog多周期CPU设计文档——异常处理

*注：表格中空着的两行均是为以后的扩展而留出的*

## 设计要求

- 设计一个32位五级流水线cpu
- cpu支持`add, sub, and, or, slt, sltu, lui`
  `addi, andi, ori`
  `lb, lh, lw, sb, sh, sw`
  `mult, multu, div, divu, mfhi, mflo, mthi, mtlo`
  `beq, bne, jal, jr` `eret，mtc0，mfc0`操作

## 顶层设计（参考课件）

![](C:\Users\17451\Desktop\新建文件夹\dxJgXYyS4wa9KQk.png)

文件树形结构层次如下：

![](C:\Users\17451\Desktop\新建文件夹\微信截图_20231215103757.png)

## 模块定义

### 顶层模块：mips

| 信号名               | 方向 | 描述                                       |      |
| -------------------- | ---- | ------------------------------------------ | ---- |
| clk                  | I    | 时钟信号                                   |      |
| reset                | I    | 复位信号                                   |      |
| i_inst_addr[31:0]    | O    | 需要进行取指操作的流水级 PC（一般为 F 级） |      |
| I_inst_rdata[31:0]   | I    | i_inst_addr 对应的 32 位指令               |      |
| m_data_rdata[31:0]   | I    | 数据存储器存储的相应数据                   |      |
| m_data_addr[31:0]    | O    | 待写入/读出的数据存储器相应地址            |      |
| m_data_wdata[31:0]   | O    | 待写入数据存储器相应数据                   |      |
| m_data_byteen[3:0]   | O    | 四位字节使能                               |      |
| m_inst_addr[31:0]    | O    | M 级 PC                                    |      |
| w_grf_we             | O    | 写grf使能信号                              |      |
| w_grf_addr[4:0]      | O    | 写grf的地址                                |      |
| w_grf_wdata[31:0]    | O    | 写入数据                                   |      |
| w_inst_addr[31:0]    | O    | W级PC                                      |      |
| m_int_addr[31:0]     | O    | 中断发生器待写入地址                       |      |
| m_int_byteen[3:0]    | O    | 中断发生器字节使能信号                     |      |
| interrupt            | I    | 外部中断                                   |      |
| macroscopic_pc[31:0] | O    | 宏观PC                                     |      |

```verilog
assign m_int_addr=M_ALU_res;
assign m_int_byteen=m_data_byteen;
assign macroscopic_pc=((M_PC != 0) || (M_excCode == 4)) ? {M_PC[31:2], 2'b0} :
					((E_PC != 0) || (E_excCode == 4)) ? {E_PC[31:2], 2'b0} :
					((D_PC != 0) || (D_excCode == 4)) ? {D_PC[31:2], 2'b0} :
					{F_PC[31:2], 2'b0};
```



### Blocker（阻塞模块）

| 信号名    | 方向 | 描述                              |
| --------- | ---- | --------------------------------- |
| E_RegAddr | I    | E级指令写指令的目标寄存器地址     |
| M_RegAddr | I    | M级指令写指令的目标寄存器地址     |
| D_rs      | I    | A1                                |
| D_rt      | I    | A2                                |
| D_Tues_rs | I    | 位于D级指令还需要多久用到rs寄存器 |
| D_Tues_rt | I    | 位于D级指令还需要多久用到rt寄存器 |
| E_Tnew    | I    | 位于E级指令产生新数据还需要多久   |
| M_Tnew    | I    | 位于M级指令产生新数据还需要多久   |
| ifBlock   | O    | 阻塞控制信号                      |
| D_md      | I    | 乘除信号                          |
| D_mt      | I    | mthi、mtlo信号                    |
| D_mf      | I    | mfhi、mflo信号                    |
| E_Start   | I    | MDU相关指令开始信号               |
| E_Busy    | I    | MDU正在执行相关指令的信号         |

**一共有六种情况需要阻塞**

新增：

```verilog
wire stall_eret = D_eret & ((E_mtc0 & (E_RegAddr == 5'd14)) || (M_mtc0 & (M_RegAddr == 5'd14)));
```



### 转发实现

```verilog
//--------------------向D级转发---------------------------------
	 wire [31:0]D_FWD_RD1_data;
	 wire [31:0]D_FWD_RD2_data;
	 assign D_FWD_RD1_data=(D_code25_21==0)?0:
						   (D_code25_21==E_RegAddr)?E_RegData:
						   (D_code25_21==M_RegAddr)?M_RegData:
						  //(D_code25_21==W_RegAddr)?W_RegData:
								  D_RD1;
	 assign D_FWD_RD2_data=(D_code20_16==0)?0:
						   (D_code20_16==E_RegAddr)?E_RegData:
						   (D_code20_16==M_RegAddr)?M_RegData:
						//(D_code20_16==W_RegAddr)?W_RegData:
								  D_RD2;

//---------------------向E级转发-----------------------------------
	 wire [31:0]E_FWD_RD1_data;
	 wire [31:0]E_FWD_RD2_data;
	 assign E_FWD_RD1_data=(E_code25_21==0)?0:
						   (E_code25_21==M_RegAddr)?M_RegData:
						   (E_code25_21==W_RegAddr)?W_RegData:
								  E_RD1_data;
	 assign E_FWD_RD2_data=(E_code20_16==0)?0:
						   (E_code20_16==M_RegAddr)?M_RegData:
						   (E_code20_16==W_RegAddr)?W_RegData:
								  E_RD2_data;
//----------------------向M级转发---------------------------------
	 wire [31:0]M_FWD_RD2_data;
	 assign M_FWD_RD2_data=(M_code20_16==0)?0:
						   (M_code20_16==W_RegAddr)?W_RegData:
						   M_RD2_data;
//-------------------------------------------------------------
	 assign W_RegData=(W_SelWd==2'd0)?W_RD:
					  (W_SelWd==2'd1)?W_ALU_res:
					  (W_SelWd==2'd2)?W_PC+32'd8:
         			  (W_SelWd==2'd3)?W_MDU_res:
                      (W_SelWd==3'd4)?W_CP0Out://新增
         //需要将指令地址写入寄存器的指令 应写入pc+8(原pc+4)！！
						 0;
						 
	 assign M_RegData=(M_SelWd==2'd2)?M_PC+32'd8:
         			  (M_SelWd==2'd3)?M_MDU_res:
        			  M_ALU_res;
	 assign E_RegData=(E_SelWd==2'd2)?E_PC+32'd8:0;
```

**请注意只有写指令才会提供数据，因此在此做转发的时候要注意，即使当D_code25_21==E_RegAddr时，还需要在E级的指令是写指令才行，不然会进行不必要的转发，具体实现在CRTL中**

### F_IFU（取指令单元）

NPC端口说明：

| 信号名     | 方向 | 描述                                             |
| ---------- | ---- | ------------------------------------------------ |
| PC[31:0]   | I    | 当前指令地址                                     |
| NPCop[2:0] | I    | 输入控制信号                                     |
| Ra[31:0]   | I    | 输入$ra保存的地址                                |
| Zero       | I    | 判断`$rs`和`$rt`是否相等，相等为1，否则为0       |
| NPC[31:0]  | O    | 输出下条指令的地址                               |
| Imm[25:0]  | I    | 包括beq的16位指令的扩展以及j和jr指令的26位立即数 |
| PC+4[31:0] | o    | 输出pc+4的值                                     |
| Clk        | I    |                                                  |
| Reset      | I    |                                                  |
| EPC[31:0]  | I    | EPC，待返回的pc                                  |
| Req        | I    | 异常处理控制信号，进入0x4180                     |
| excAdEL    | O    | 取指异常                                         |

```verilog
assign excAdEL = ((|pc[1:0]) | (pc < `StartInstr) | (pc > `EndInstr)) && !eret;
```

npc：

```verilog
assign Npc=(Req) ? 32'h0000_4180 :
					(eret) ? EPC :
					(NPCop==3'd0)?Npc_1:
					(NPCop==3'd1)?Npc_2:
					(NPCop==3'd2)?Npc_3:
					(NPCop==3'd3)?Npc_4:
					Npc_5;
```



| 控制信号 | 功能            |
| -------- | --------------- |
| 3’b000   | 输出PC+4        |
| 3’b001   | 执行beq的跳转   |
| 3’b010   | 执行j/jal的指令 |
| 3’b011   | 执行jr的指令    |
| 3’b100   | 执行bne指令     |
|          |                 |

PC：用寄存器即可

```verilog
assign i_inst_addr=F_PC;
	 assign F_Instr=(F_excAdEL) ? 32'd0 : i_inst_rdata;
```



### D_CRTL（控制器,实例化四次）

| 信号名         | 方向 | 描述                                                        |
| -------------- | ---- | ----------------------------------------------------------- |
| Instr[31:0]    | I    | 输入指令                                                    |
| ALUop[3:0]     | O    | ALU控制信号                                                 |
| ALUsel         | O    | 选择立即数/寄存器值进行运算                                 |
| DMwr           | O    | DM使能信号                                                  |
| NPCop[2:0]     | O    | NPC控制信号                                                 |
| EXTop          | O    | EXT控制信号                                                 |
| WE             | O    | GRF使能信号                                                 |
| SelWr[1:0]     | O    | 待写入寄存器地址控制信号                                    |
| SelWd[1:0]     | O    | 写入寄存器数据控制信号                                      |
| DMop[1:0]      | O    | DM控制信号                                                  |
| code25_21[4:0] | O    | rs                                                          |
| code20_16[4:0] | O    | rt                                                          |
| code15_11[4:0] | O    | code15_11                                                   |
| Imm16[15:0]    | O    | Imm16                                                       |
| Imm26[25:0]    | O    | Imm26                                                       |
| MDUop[3:0]     | O    | 乘除相关指令控制信号                                        |
| MDUsel         | O    | 选择hi or lo寄存器写入                                      |
| Start          | O    | 乘除槽相关指令开始信号                                      |
| md             | O    | 在D级发给Blocker模块                                        |
| mf             | O    | 在D级发给Blocker模块                                        |
| mt             | O    | 在D级发给Blocker模块                                        |
| Regaddr[4:0]   | O    | 写指令写入寄存器的地址（非写指令则为0）                     |
| D_Tuse_rs[2:0] | O    | 位于D级的指令还要多少个周期才需要用到rs寄存器的值           |
| D_Tuse_rt[2:0] | O    | 位于D级的指令还要多少个周期才需要用到rt寄存器的值           |
| E_Tnew[2:0]    | O    | 位于E级的指令还需要多少个周期才能产生新值并写入流水线寄存器 |
| M_Tnew[2:0]    | O    | 位于M级的指令还需要多少个周期才能产生新值并写入流水线寄存器 |
| eret           | O    | 该指令为eret                                                |
| excRI          | O    | 未知指令                                                    |
| ALUAriOv       | O    | 是否需要判断ALU算术溢出                                     |
| ALUDMOv        | O    | 是否需要判断ALU计算存取地址溢出                             |
| CP0WE          | O    | CP0写使能                                                   |
| BD             | O    | 是否为延迟槽                                                |
| mtc0           | O    | 是否为mtc0指令                                              |
| load           | O    | 是否是为取指令                                              |
| store          | O    | 是否为存指令                                                |

1.SelWr功能说明

| 控制信号值 | 功能                             |
| ---------- | -------------------------------- |
| 2’b00      | 选择待写入寄存器地址为15-11      |
| 2’b01      | 选择待写入寄存器地址为20-16      |
| 2’b10      | 选择待写入寄存器为`$31`（`$ra`） |

2.SelWd功能说明

| 控制信号值 | 功能                                  |
| ---------- | ------------------------------------- |
| 2’b00      | 选择写入寄存器的数据来自DM            |
| 2’b01      | 选择写入寄存器的数据来自ALU的计算结果 |
| 2’b10      | 选择写入寄存器的数据来自PC+8          |
| 2’b11      | 选择写入寄存器的数据来自MDU的计算结果 |

对应代码实现：

```verilog
assign load=(LW|LH|LB);
	 assign store=(SW|SH|SB);
	 
	 assign mtc0=MTC0;
	 assign BD=(BEQ|BNE|J|JAL|JR);
	 assign CP0WE=MTC0;
	 assign ALUDMOv= (LB |  LH | LW | SB | SH | SW);
	 assign ALUAriOv=(ADD|ADDI|SUB);
	 assign excRI=!(ADD|SUB|ORI|LW|SW|BEQ|LUI|J|JAL|JR|
						ERET|BNE|LH|SH|LB|SB|AND|ADDI|OR|ANDI|SLT|SLTU|
						MULT|MULTU|DIV|DIVU|MFHI|MFLO|MTHI|MTLO|
						(opcode==6'b0&&funct==6'b0)|MTC0|MFC0);
```

对于流水线寄存器FD、DE、EM均需要将BD信号流水，，这里不再赘述；此外还有异常和中断码也需流水到M级的CP0，并根据先后顺序处理

先后顺序实现如下：

```verilog
assign F_excCode = F_excAdEL ? `EXC_AdEL : `EXC_None;

	assign D_excCode =  D_old_excCode ? D_old_excCode : // D_old_excCode 是 F 级发生的异常，后面同理
							  D_excRI ? `EXC_RI :
                      `EXC_None;

	assign E_excCode =  E_old_excCode ? E_old_excCode :
							  E_excOvAri ? `EXC_Ov :
                      `EXC_None;

	assign M_excCode =  M_old_excCode ? M_old_excCode :
                    M_excAdEL ? `EXC_AdEL :
                    M_excAdES ? `EXC_AdES :
                    `EXC_None;
```



### FD_REG流水线寄存器

| 信号名        | 方向 | 描述           |
| ------------- | ---- | -------------- |
| Clk           | I    | 时钟信号       |
| Reset         | I    | 复位信号       |
| flush         | I    | 寄存器清零信号 |
| FD_en         | I    | 寄存器使能信号 |
| F_PC[31:0]    | I    | F级的PC        |
| F_Instr[31:0] | I    | F级的Instr指令 |
| D_PC[31:0]    | O    | D级PC          |
| D_Instr[31:0] | O    | D级Instr指令   |

### D_GRF

利用P0的课下即可

![](C:\Users\17451\Desktop\五级流水线cpu设计文档\GRF模块设计.png)

**注意寄存器内部转发：**

```verilog
assign RD1=(A1==0)?0:
		(A1==A3&&A1!=0)?WD:
			rf[A1];
assign RD2=(A2==0)?0:
		(A2==A3&&A2!=0)?WD:
		rf[A2];
```



### D_EXT

将16位立即数扩展成32位

| 信号名    | 方向 | 描述           |
| --------- | ---- | -------------- |
| Imm[15:0] | I    | 待扩展的16位数 |
| extOut    | O    | 扩展后的32位数 |
| EXTop     | I    | 控制信号       |

| 控制信号值 | 操作         |
| ---------- | ------------ |
| 1’b0       | 进行零扩展   |
| 1’b1       | 进行符号扩展 |

### D_CMP（比较器）

| 信号名    | 方向 | 描述                        |
| --------- | ---- | --------------------------- |
| RD1[31:0] | I    | 处理完转发后`$rs`寄存器的值 |
| RD2[31:0] | I    | 处理完转发后`$rt`寄存器的值 |
| zero      | O    | 是否相等                    |

### DE_REG（D/E级流水线寄存器）

| 信号名           | 方向 | 描述                   |
| ---------------- | ---- | ---------------------- |
| Clk              | I    | 时钟信号               |
| Reset            | I    | 复位信号               |
| flush            | I    | 寄存器清零信号（阻塞） |
| DE_en            | I    | 流水线寄存器使能信号   |
| D_PC[31:0]       | I    | D级PC                  |
| D_Instr[31:0]    | I    | D级指令                |
| D_EXT_Imm[31:0]  | I    | D级经扩展的32位立即数  |
| D_RD1_data[31:0] | I    | D级RD1的值             |
| D_RD2_data[31:0] | I    | D级RD2的值             |
| E_PC[31:0]       | O    | E级PC的值              |
| E_Instr[31:0]    | O    | E级Instr的值           |
| E_EXT_Imm[31:0]  | O    | E级经扩展的32位立即数  |
| E_RD1_data[31:0] | O    | E级RD1的值             |
| E_RD2_data[31:0] | O    | E级RD2的值             |

### E_CRTL（E级控制模块）



### E_ALU

| 信号名     | 方向 | 描述      |
| ---------- | ---- | --------- |
| A[31:0]    | I    | 运算数A   |
| B[31:0]    | I    | 运算数B   |
| C[31:0]    | O    | 运算结果C |
| ALUop[3:0] | I    | 控制信号  |

控制信号：

| 控制信号值 | 功能       |
| ---------- | ---------- |
| 4’b0000    | 加法运算   |
| 4’b0001    | 减法运算   |
| 4’b0010    | or\ori运算 |
| 4’b0011    | lui运算    |
| 4‘b0100    | and        |
| 4’b0101    | slt        |
| 4’b0110    | sltu       |
|            |            |

ALUsel功能说明

| 控制信号值 | 功能                   |
| ---------- | ---------------------- |
| 1‘b0       | 选择寄存器的值进行运算 |
| 1’b1       | 选择立即数进行运算     |

注：and运算为自行扩展

异常判断如下：

```verilog
wire [32:0] ext_A = {A[31], A}, ext_B = {B[31], B};
    wire [32:0] ext_add = ext_A + ext_B;
    wire [32:0] ext_sub = ext_A - ext_B;
    assign excOvAri = (ALUAriOv) && 
                       ((ALUop == `ALU_add && ext_add[32] != ext_add[31]) ||
                       (ALUop == `ALU_sub && ext_sub[32] != ext_sub[31]));
    assign excOvDM = (ALUDMOv) && 
                       ((ALUop == `ALU_add && ext_add[32] != ext_add[31]) ||
                       (ALUop == `ALU_sub && ext_sub[32] != ext_sub[31]));
```



### E_MDU

| 信号名 | 方向 | 描述                                         |
| ------ | ---- | -------------------------------------------- |
| Clk    | I    | 时钟信号                                     |
| Reset  | I    | 复位信号                                     |
| A      | I    | 经过转发后的`$rs`寄存器的值                  |
| B      | I    | 经过转发后的`$rt`寄存器的值                  |
| Start  | I    | 乘除槽相关指令开始信号                       |
| MDUop  | I    | 乘除槽相关指令控制信号（决定具体是哪条指令） |
| MDUsel | I    | 选择hi or lo寄存器写入                       |
| C      | O    | 输出乘除后的结果                             |
| Busy   | O    | MDU是否正在执行指令                          |



MDUop功能说明

| 控制信号值 | 功能  |
| ---------- | ----- |
| 4’b0000    | mult  |
| 4’b0001    | multu |
| 4’b0010    | div   |
| 4’b0011    | divu  |
| 4’b0100    | mfhi  |
| 4’b0101    | mflo  |
| 4’b0110    | mthi  |
| 4’b0111    | mtlo  |
|            |       |

MDUsel功能说明

| 控制信号值 | 功能                 |
| ---------- | -------------------- |
| 1’b0       | 选择LO寄存器作为输出 |
| 1‘b1       | 选择HI寄存器作为输出 |



### EM_REG（流水线寄存器）

*具体描述参考上文，这里不再赘述*

| 信号名           | 方向 | 描述 |
| ---------------- | ---- | ---- |
| Clk              | I    |      |
| Reset            | I    |      |
| flush            | I    |      |
| EM_en            | I    |      |
| E_PC[31:0]       | I    |      |
| E_Instr[31:0]    | I    |      |
| E_EXT_Imm[31:0]  | I    |      |
| E_RD2_data[31:0] | I    |      |
| E_ALU_res[31:0]  | I    |      |
| E_MDU_res[31:0]  | I    |      |
| M_PC[31:0]       | O    |      |
| M_Instr[31:0]    | O    |      |
| M_EXT_Imm[31:0]  | O    |      |
| M_RD2_data[31:0] | O    |      |
| M_ALU_res[31:0]  | O    |      |
| M_MDU_res[31:0]  | O    |      |

### M_CRTL（M级控制模块）

### M_DM_IN（DM输入处理模块）

| 信号名             | 方向 | 描述                                            |
| ------------------ | ---- | ----------------------------------------------- |
| DMop[1:0]          | I    | dm控制信号（对应word、half、byte）              |
| addr[31:0]         | I    | ALU计算结果即数据存入地址                       |
| WD[31:0]           | I    | 经转发后的`$rt`寄存器的值，即存入数据（处理前） |
| DMwr               | I    | dm写使能信号                                    |
| m_data_byteen[3:0] | O    | 四位字节使能                                    |
| m_data_wdata[31:0] | O    | 处理后的要写入的数据                            |

异常判断：

```verilog
wire ErrAlign = ((DMop == `sw) && (|addr[1:0])) ||
                    ((DMop == `sh) && (addr[0]));
    
    wire ErrOutOfRange = !(((addr >= `StartAddrDM) && (addr <= `EndAddrDM)) ||
                           ((addr >= `StartAddrTC0) && (addr <= `EndAddrTC0)) ||
                           ((addr >= `StartAddrTC1) && (addr <= `EndAddrTC1)));
    
    wire ErrTimer = (addr >= 32'h0000_7f08 && addr <= 32'h0000_7f0b) ||
                    (addr >= 32'h0000_7f18 && addr <= 32'h0000_7f1b) ||
                    (DMop != `sw && addr >= `StartAddrTC0);
    assign excAdES = (store) && (ErrAlign || ErrOutOfRange || ErrTimer || excOvDM);
```



### M_DM_OUT（DM输出处理模块）

| 信号名         | 方向 | 描述                               |
| -------------- | ---- | ---------------------------------- |
| DMop[1:0]      | I    | dm控制信号（对应word、half、byte） |
| addr[31:0]     | I    | ALU计算结果即数据存入地址          |
| DM_value[31:0] | I    | 从DM读出的值                       |
| RD[31:0]       | O    | 经处理后从dm读出的值               |

异常判断：

```verilog
wire ErrAlign = ((DMop == `lw) && (|addr[1:0])) ||
                    ((DMop == `lh ) && (addr[0]));
    
    wire ErrOutOfRange = !(((addr >= `StartAddrDM) && (addr <= `EndAddrDM)) ||
                           ((addr >= `StartAddrTC0) && (addr <= `EndAddrTC0)) ||
                           ((addr >= `StartAddrTC1) && (addr <= `EndAddrTC1)));
    
    wire ErrTimer = (DMop != `lw) && (addr >= `StartAddrTC0);
    assign excAdEL = (load) && (ErrAlign || ErrOutOfRange || ErrTimer || excOvDM);
```



### CP0协处理器

| 信号名         | 方向 | 描述              |
| -------------- | ---- | ----------------- |
| Clk            | I    |                   |
| Reset          | I    |                   |
| WE             | I    | 写使能            |
| CP0Add[4:0]    | I    | 写3个处理器之一   |
| CP0In[31:0]    | I    | 输入数据（mtc0）  |
| CP0Out[31:0]   | O    | 输出（mfc0）      |
| PC[31:0]       | I    |                   |
| BDIn           | I    | 是否为延迟槽      |
| ExcCodeIn[4:0] | I    | 异常与中断码      |
| HWInt[5:0]     | I    | 外部中断          |
| EXLClr         | I    | 清空exl           |
| EPCOut[31:0]   | O    | 输出epc寄存器的值 |
| Req            | O    | 异常信号          |

### Bridge系统桥

| 信号名        | 方向 | 描述           |
| ------------- | ---- | -------------- |
| PrAddr[31:2]  | I    | 写入的内存地址 |
| PrWD[31:0]    | I    | 写入的数据     |
| PrWE          | I    | 写使能         |
| DEV0RD[31:0]  | I    | tc0输出        |
| DEV1RD[31:0]  | I    | tc1输出        |
| PrRD[31:0]    | O    | dm输出         |
| DEVAddr[31:2] | O    | 写地址         |
| DEVWD[31:0]   | O    | 写数据         |
| DEV0WE        | O    | tc0写使能      |
| DEV1WE        | O    | tc1写使能      |

写使能判断：

```verilog
wire HitDEV=(32'h7F00 <= M_ALU_res && M_ALU_res <= 32'h7F0B) ||
					 (32'h7F10 <= M_ALU_res && M_ALU_res <= 32'h7F1B);
	 wire HitDM=(M_ALU_res < 32'h3000);
	 wire PrWE=M_DMwr&HitDEV&!Req;
```



### TC0 TC1已写好

### MW_REG（M/W级流水线寄存器）

*具体描述参考上文，这里不再赘述*

| 信号名          | 方向 | 描述 |
| --------------- | ---- | ---- |
| Clk             | I    |      |
| Reset           | I    |      |
| flush           | I    |      |
| MW_en           | I    |      |
| M_PC[31:0]      | I    |      |
| M_Instr[31:0]   | I    |      |
| M_RD[31:0]      | I    |      |
| M_ALU_res[31:0] | I    |      |
| M_MDU_res[31:0] | I    |      |
| W_PC[31:0]      | O    |      |
| W_Instr[31:0]   | O    |      |
| W_RD[31:0]      | O    |      |
| W_ALU_res[31:0] | O    |      |
| W_MDU_res[31:0] | O    |      |

### M_CRTL（M级控制模块）



### 数据通路分析（多余不赘述）

| 指令 | ALUsel | ALUop | DMwr | SelWr | SelWd | NPCop | EXTop | WE   |
| ---- | ------ | ----- | ---- | ----- | ----- | ----- | ----- | ---- |
| add  | 0      | 0000  | 0    | 00    | 01    | 000   | X     | 1    |
| sub  | 0      | 0001  | 0    | 00    | 01    | 000   | X     | 1    |
| ori  | 1      | 0010  | 0    | 01    | 01    | 000   | 0     | 1    |
| lw   | 1      | 0000  | 0    | 01    | 00    | 000   | 1     | 1    |
| sw   | 1      | 0000  | 1    | X     | X     | 000   | 1     | 0    |
| beq  | 0      | 0000? | 0    | X     | X     | 001   | X     | 0    |
| lui  | 1      | 0011  | 0    | 01    | 01    | 000   | X     | 1    |
| j    | X      | X     | 0    | X     | X     | 010   | X     | 0    |
| jal  | X      | X     | 0    | 10    | 10    | 010   | X     | 1    |
| jr   | X      | X     | 0    | X     | X     | 011   | X     | 0    |
| lh   | 1      | 0000  | 0    | 01    | 00    | 000   | 1     | 1    |
| sh   | 1      | 0000  | 1    | X     | X     | 000   | 1     | 0    |
| sb   | 1      | 0000  | 1    | X     | X     | 000   | 1     | 0    |
| lb   | 1      | 0000  | 1    | 01    | 00    | 000   | 1     | 1    |
| addi | 1      | 0000  | 0    | 01    | 01    | 000   | 1     | 1    |
| or   | 0      | 0010  | 0    | 00    | 01    | 000   | X     | 1    |
| slt  | 0      | 0101  | 0    | 00    | 01    | 000   | X     | 1    |
| sltu | 0      | 0110  | 0    | 00    | 01    | 000   | X     | 1    |
| and  | 0      | 0100  | 0    | 00    | 01    | 000   | X     | 1    |
| andi | 1      | 0100  | 0    | 01    | 01    | 000   | 0     | 1    |
| bne  | 0      | 0000  | 0    | X     | X     | 010   | 1     | 0    |
|      |        |       |      |       |       |       |       |      |
|      |        |       |      |       |       |       |       |      |
|      |        |       |      |       |       |       |       |      |

## 测试

首先写mips测试程序：

```mips
lui $20 0x3db8
lui $21 0x6ed4
add $21 $20 $21
lui $20 0x7fff
addi $20 $20 32767
addi $20 $20 32767
addi $21 $20 32712
lui $20 0x80d1
lui $21 0x7904
sub $21 $20 $21
sltu $21 $9 $17
ori $16 $16 1
divu $13 $16
ori $8 $8 17582
mtlo $21
addi $13 $9 -15606
mtlo $20
ori $11 $0 14136
lh $8 -7224($11)
ori $13 $0 27497
lw $16 -23965($13)
ori $14 $14 1
div $16 $14
andi $11 $21 19194
slt $15 $21 $19
mfhi $15
lui $11 0xb416
ori $14 $12 4554
ori $9 $9 1
divu $8 $9
ori $9 $0 19991
sw $21 -13163($9)
lui $11 0xb9fa
ori $8 $0 27048
sb $17 -24976($8)
sub $14 $12 $9
sltu $21 $10 $15
ori $21 $21 1
divu $11 $21
mtlo $20
multu $14 $12
ori $8 $0 28732
sh $13 -27876($8)
ori $20 $0 31054
sw $14 -29798($20)
add $8 $18 $8
andi $13 $8 25580
mtlo $9
mfhi $15
ori $15 $0 19327
sb $11 -8368($15)
mult $12 $13
ori $16 $16 1
div $11 $16
mfhi $13
ori $16 $0 7808
lh $16 4030($16)
ori $20 $0 24892
......
```

将其导出为16进制txt文件放入ise文件夹中

然后进行仿真，得到输出与mars对拍：

```
1	@00003000: $20 <= 3db80000	f	1	@00003000: $20 <= 3db80000
2	@00003004: $21 <= 6ed40000		2	@00003004: $21 <= 6ed40000
3	@00004180: $26 <= 00000002		3	@00004180: $26 <= 00000002
4	@00004184: $26 <= 00000002		4	@00004184: $26 <= 00000002
5	@00004190: $26 <= 00001000		5	@00004190: $26 <= 00001000
6	@00004194: $26 <= 00000f00		6	@00004194: $26 <= 00000f00
7	@00004198: *00000f74 <= 00000000		7	@00004198: *00000f74 <= 00000000
8	@0000419c: $29 <= 00000f00		8	@0000419c: $29 <= 00000f00
9	@000041a0: *00000f20 <= 00000000		9	@000041a0: *00000f20 <= 00000000
10	@000041a4: *00000f24 <= 00000000		10	@000041a4: *00000f24 <= 00000000
11	@000041a8: *00000f7c <= 00000000		11	@000041a8: *00000f7c <= 00000000
12	@000041ac: $26 <= 00000000		12	@000041ac: $26 <= 00000000
13	@000041b0: $27 <= 00000000		13	@000041b0: $27 <= 00000000
14	@000041b4: *00000f80 <= 00000000		14	@000041b4: *00000f80 <= 00000000
15	@000041b8: *00000f84 <= 00000000		15	@000041b8: *00000f84 <= 00000000
16	@000041bc: $31 <= 000041c4		16	@000041bc: $31 <= 000041c4
17	@000041c4: $26 <= 00000030		17	@000041c4: $26 <= 00000030
18	@000041c8: $27 <= 80000000		18	@000041c8: $27 <= 80000000
19	@000041cc: $ 8 <= 00000000		19	@000041cc: $ 8 <= 00000000
20	@000041d8: $31 <= 000041e0		20	@000041d8: $31 <= 000041e0
21	@000041dc: $27 <= 00003008		21	@000041dc: $27 <= 00003008
22	@000041e8: $27 <= 0000007c		22	@000041e8: $27 <= 0000007c
23	@000041ec: $26 <= 00000030		23	@000041ec: $26 <= 00000030
24	@000041f8: $27 <= 00000010		24	@000041f8: $27 <= 00000010
25	@00004204: $31 <= 0000420c		25	@00004204: $31 <= 0000420c
26	@00004258: $26 <= 00003008		26	@00004258: $26 <= 00003008
27	@0000425c: $26 <= 0000300c		27	@0000425c: $26 <= 0000300c
28	@00004264: $31 <= 0000426c		28	@00004264: $31 <= 0000426c
29	@000042b0: $ 8 <= 00000000		29	@000042b0: $ 8 <= 00000000
30	@000042b4: $ 9 <= 00000000		30	@000042b4: $ 9 <= 00000000
31	@000042b8: $26 <= 00000000		31	@000042b8: $26 <= 00000000
32	@000042bc: $27 <= 00000000		32	@000042bc: $27 <= 00000000
33	@000042c0: $31 <= 00000000		33	@000042c0: $31 <= 00000000
34	@000042cc: $29 <= 00000000		34	@000042cc: $29 <= 00000000
35	@0000300c: $20 <= 7fff0000		35	@0000300c: $20 <= 7fff0000
36	@00003010: $20 <= 7fff7fff		36	@00003010: $20 <= 7fff7fff
37	@00003014: $20 <= 7ffffffe		37	@00003014: $20 <= 7ffffffe
......
```

测试完成！

## 思考题

1. **请查阅相关资料，说明鼠标和键盘的输入信号是如何被 CPU 知晓的？**

我们每按下一次键盘，就相当与向CPU发起一次中断，将输入信号从鼠标和键盘中读入寄存器。

2. **请思考为什么我们的 CPU 处理中断异常必须是已经指定好的地址？如果你的 CPU 支持用户自定义入口地址，即处理中断异常的程序由用户提供，其还能提供我们所希望的功能吗？如果可以，请说明这样可能会出现什么问题？否则举例说明。（假设用户提供的中断处理程序合法）**

我认为这与系统安全性和稳定性、权限管理和统一管理有关。预先指定的中断处理程序地址可以确保在发生异常时，CPU能够跳转到一个已知、经过验证且可靠的代码位置，正确地处理异常；中断异常的处理通常涉及到权限，如果允许用户自定义中断处理程序的入口地址，可能会导致用户能够在特权级别上进行不受限制的操作，从而破坏系统的安全性；操作系统需要能够控制和管理中断处理的过程，以确保整个系统的稳定性和一致性。

可以，但若操作不当可能会对存储有 CPU 初始数据和命令的地址区域进行读写，或将连续的地址空间分割，增加了数据丢失和指令处理混乱的风险，并且设计难度高且没有必要。

3. **为何与外设通信需要 Bridge？**

外设往往不止一个，而CPU不能为每个设备都提供一套地址/数据，因此增加系统桥可以使 CPU 以相对固定的方式读取或写入不同的外设，并且在系统需要增添外设时，只需要添加相应的读写地址的映射，可拓展性良好。

4. **请阅读官方提供的定时器源代码，阐述两种中断模式的异同，并针对每一种模式绘制状态移图。**

相同：都从初值寄存器中获取初数值。

不同：模式0当计数器倒计数为 0 后，计数器停止计数，当使能 Enable 被设置为 1 后，初值寄存器值再次被加载至计数器，计数器重新启动倒计数。而模式1当计数器倒计数为 0 后，初值寄存器值被自动加载至计数器，计数器继续倒计数。

![](C:\Users\17451\Desktop\新建文件夹\微信图片_20231215115811.jpg)

5. **倘若中断信号流入的时候，在检测宏观 PC 的一级如果是一条空泡（你的 CPU 该级所有信息均为空）指令，此时会发生什么问题？在此例基础上请思考：在 P7 中，清空流水线产生的空泡指令应该保留原指令的哪些信息？**

此时宏观 PC 会显示错误的值。并且如果此时发生了中断，就会导致 EPC 存入错误的值。如果插入了 `nop`，它的 `PC` 和 `bd` 应该是目前这条指令的值。具体操作在流水线寄存器中。

6. **为什么 `jalr` 指令为什么不能写成 `jalr $31, $31`？**

若读写同一寄存器，则当前pc的值加4会被再次写入该寄存器，若产生异常，则当前CPU结构无法消除其已经改变的值，造成错误的指令行为。

##  Logisim参考

![](C:\Users\17451\Desktop\五级流水线cpu设计文档\main.png)

![](C:\Users\17451\Desktop\五级流水线cpu设计文档\NPC.png)

![](C:\Users\17451\Desktop\五级流水线cpu设计文档\DM.png)
